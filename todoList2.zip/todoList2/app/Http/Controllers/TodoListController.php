<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ListItem;

class TodoListController extends Controller
{
    public function saveItem(request $request)
    {
        \Log::info(json_encode($request->all()));
        $newListItem = new ListItem;
        $newListItem->leiras = $request->ListesItem;
        $newListItem->befejezett = 0;
        $newListItem->save();

        // return view('welcome',['ListItems'=>ListItem::all()]);
        return redirect('/');
    }

    public function index()
    {

        // return view('welcome',['ListItems'=>ListItem::all()]);
        return view('welcome', ['ListItems' => ListItem::where('befejezett', 0)->get()]);
    }
    public function rendbenVan($id)
    {
        $listItem = ListItem::find($id);
        $listItem->befejezett = 1;
        $listItem->save();
        return redirect('/');
    }
}
