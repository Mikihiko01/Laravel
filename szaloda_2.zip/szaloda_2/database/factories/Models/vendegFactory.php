<?php

namespace Database\Factories\Models;

use Illuminate\Database\Eloquent\Factories\Factory;

class vendegFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
