<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFoglalasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('foglalas', function (Blueprint $table) {
            // $table->id();
            $table->increments('fazon');
            $table->integer('vazon')->unsigned();
            $table->unsignedBigInteger('szam');
            $table->index('vazon');
            $table->index('szam');
            $table->foreign('vazon')->references('vazon')->on('vendegs');
            $table->foreign('szam')->references('szam')->on('szobas');
            $table->date('datumtol');
            $table->date('datumig');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('foglalas');
    }
}
